# 기본 실습

1. Xcode에서 ClosedWorldLab이라는 iOS App을 만듭니다. SwiftUI, Swift, Storage None을 선택합니다.
2. Starter 안의 SceneSupport.swift와 Piggy.usdc 두 파일만 앱에 추가합니다.
3. 기존 ContentView.swift를 튜토리얼의 첫 코드로 교체합니다.
4. 시뮬레이터를 선택하고 실행한 뒤 위치, 탭 이동을 차례로 바꿔 봅니다.

Answers는 막혔을 때 비교하는 전체 코드입니다. 폴더를 통째로 Xcode에 넣지 마세요.
해당 단계의 ContentView.swift 내용만 복사해 기존 파일을 교체합니다.

SceneSupport.swift는 기본 실습에서 수정하지 않습니다. 모델 파일이 빠져도 분홍 상자로 진행할 수 있습니다.
ClosedWorldLabApp.swift는 Xcode가 만든 상태로 둡니다.
