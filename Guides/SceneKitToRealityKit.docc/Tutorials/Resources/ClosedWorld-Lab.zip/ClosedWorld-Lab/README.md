# ClosedWorld 실습 자료

Xcode에서 iOS App을 만들고 Product Name ClosedWorldLab, SwiftUI, Swift를 선택하세요.
기본 ClosedWorldLabApp.swift는 그대로 둡니다.

- 튜토리얼을 처음부터 따라 할 때: Models/Piggy.usdc만 필요에 따라 추가합니다.
- 중간에 막혔을 때: Checkpoints/1~5 중 해당 구간의 Swift 파일만 사용하세요.
  같은 이름의 기존 파일은 내용을 교체하고 없는 파일만 새로 추가합니다.
  여러 Checkpoints 폴더를 한꺼번에 앱에 넣으면 중복 선언 오류가 발생합니다.
- 모델을 추가하지 않아도 분홍 상자로 모든 단계를 따라 할 수 있습니다.
- 각 구간 끝에서 시뮬레이터를 선택하고 ⌘R로 확인하세요.

1: 빈 화면 / 2: 방 / 3: 돼지 / 4: 탭 이동 / 5: 콘솔 관찰

이 자료는 튜토리얼용 축소 예제입니다. 본편 앱의 Tuist 프로젝트를 대체하지 않습니다.
