# Chapter 4 실습 자료

1. Xcode에서 새 iOS App을 만드세요. SwiftUI, Swift, Storage None을 선택합니다.
2. Starter 안의 파일들만 앱 타깃에 복사합니다. 폴더 전체 대신 파일들을 선택하세요.
3. 기존 ContentView.swift를 해당 단계의 Answers/1, 2, 3 안에 있는 파일 내용으로 교체합니다.
4. 단계마다 다시 빌드·실행하고 튜토리얼의 실행 확인과 비교하세요.

iPhone 시뮬레이터에서 실행할 수 있습니다. 카메라 권한을 추가하지 않습니다.

Answers 전체를 Xcode에 넣으면 ContentView 중복 선언 오류가 생깁니다.
막혔을 때 해당 단계 파일의 내용만 복사해 기존 ContentView.swift를 교체하세요.
모델을 읽을 수 없으면 분홍 상자가 대신 나타납니다. Piggy.usdc의 앱 Target Membership과 Copy Bundle Resources를 확인하세요.
지원 파일은 튜토리얼의 준비 코드이며 기본 실습에서 수정하지 않습니다.
iOS 최소 버전은 17입니다. 카메라·실측 평면·메시 가려짐은 지원 실기기에서 별도 확인해야 합니다.
